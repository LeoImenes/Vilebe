package com.vilebe.aluguelcarros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AluguelcarrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
